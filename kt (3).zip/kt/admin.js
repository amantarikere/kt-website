const API_URL = "http://localhost:5000";

// Fetch Users
async function fetchUsers() {
  try {
    const res = await fetch(`${API_URL}/admin/users`);
    const users = await res.json();
    const usersTable = document.getElementById("usersTable").querySelector("tbody");
    usersTable.innerHTML = "";

    users.forEach(user => {
      const row = document.createElement("tr");

      const nameCell = document.createElement("td");
      nameCell.textContent = user.name;
      row.appendChild(nameCell);

      const emailCell = document.createElement("td");
      emailCell.textContent = user.email;
      row.appendChild(emailCell);

      usersTable.appendChild(row);
    });
  } catch (err) {
    console.error("Error fetching users:", err);
  }
}

// ✅ Add Fetch Bookings
async function fetchBookings() {
  try {
    const res = await fetch(`${API_URL}/admin/bookings`);
    const bookings = await res.json();
    const table = document.getElementById("bookingsTable")?.querySelector("tbody");

    if (!table) return; // avoid error if table not present
    table.innerHTML = "";

    bookings.forEach(b => {
      const row = document.createElement("tr");

      row.innerHTML = `
        <td>${b.name}</td>
        <td>${b.email}</td>
        <td>${b.place}</td>
        <td>${b.date ? new Date(b.date).toLocaleString("en-IN") : "-"}</td>
      `;

      table.appendChild(row);
    });
  } catch (err) {
    console.error("Error fetching bookings:", err);
  }
}

// Fetch Support Requests
async function fetchSupport() {
  try {
    const res = await fetch(`${API_URL}/admin/support`);
    const requests = await res.json();
    const table = document.getElementById("supportTable").querySelector("tbody");
    table.innerHTML = "";

    requests.forEach(r => {
      const row = document.createElement("tr");

      row.innerHTML = `
        <td>${r.name}</td>
        <td>${r.email}</td>
        <td>${r.service}</td>
        <td>${r.details}</td>
        <td>${r.date ? new Date(r.date).toLocaleString("en-IN") : "-"}</td>
      `;

      table.appendChild(row);
    });
  } catch (err) {
    console.error("Error fetching support requests:", err);
  }
}

// Load everything
window.addEventListener("DOMContentLoaded", () => {
  fetchUsers();
  fetchBookings();  // now this works
  fetchSupport();
});
